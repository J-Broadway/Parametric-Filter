===INSTALLATION===
To install, right click 'install.bat' and select 'Run As Administrator'

'Parametric Filter.fst' and 'Default.fst' will be copied to the following locations:
	C:\Program Files\Image-Line\FL Studio\Presets\Plugin presets\Effects\Patcher
	C:\Program Files\Image-Line\FL Studio\Presets\Plugin presets\Effects\Control Surface

If Fl-Studio is installed in a different location, see 'Manual Installation' below.

===MANUAL INSTALLATION===
For manual installation:

	1. Open up Fl Studio
	2. In Mixer channel, load up 'Patcher'
	3. With patcher open, click the arrow in upper left-hand corner. (It's next to the gear icon).
	4. Select 'Save Preset As'
	5. Drag 'JBroadway' folder into the window that pops up.
	
	The Parametric Filter can now be opend up within patcher by selecting 'Parametric Filter.fst' as a preset.

To install the Parametric Filter default control surface configuration, follow the instructions below:
	
	1. Open up Fl Studio
	2. In Mixer channel, load up 'Patcher'
	3. With patcher open, click 'Presets' menu in top right-hand corner.
	4. Select 'Save Preset As'
	5. Drag 'Parametric Filter' folder into window that pops up.
	
	The 'default.fst' Parametric Filter UI interface can now be loaded up in control surface as a preset.